# unhcrpyplotstyle
Matplotlib style file following UNHCR data visualization guidelines
